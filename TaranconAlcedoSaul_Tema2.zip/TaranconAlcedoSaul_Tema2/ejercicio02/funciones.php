<?php
// Funcion para calcular el neto
function calcularNeto($brutoAnual, $pagas, $retencion, $complementos) {
    // Calculo mensual bruto
    $bMensual = $brutoAnual / $pagas;
    // Calculo la retencion
    $imoret = $bMensual * ($retencion / 100);
    // Calculo el neto final
    $neto = ($bMensual - $imoret) + $complementos;
    
    return [
        'b_mensual' => $bMensual,
        'retencion' => $imoret,
        'neto' => $neto
    ];
}