<!DOCTYPE html>
<head>
    <title>Reto Tema 3 - Gestión de Productos</title>
    <!-- Bootstrap por CDN para no liarme con archivos CSS locales -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="estilos.css">
</head>
<body class="bg-light p-4">

<div class="container" style="max-width: 800px;">
    <div class="p-5 mb-4 bg-white rounded-3 shadow-sm border text-center">
        <h1 class="display-5 fw-bold text-primary">Gestión de Productos</h1>
        <p class="fs-5 text-muted">Panel de control interno para la tienda de informática.</p>
        <hr class="my-4">


        <!-- Botones de acceso rapido a las dos secciones principales -->
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
            <a href="productos.php" class="btn btn-primary btn-lg px-4 gap-3">Ver / Buscar Productos</a>
            <a href="nuevo.php" class="btn btn-success btn-lg px-4">Registrar Nuevo Producto</a>
        </div>
    </div>

</div>

</body>
</html>