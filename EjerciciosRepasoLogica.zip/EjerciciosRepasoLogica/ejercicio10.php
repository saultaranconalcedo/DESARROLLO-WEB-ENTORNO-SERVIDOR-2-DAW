<?php
$resultado = "";
if (isset($_POST["frase"])) {
    $frase = $_POST["frase"];
    $palabra = "";
    $longitudMayor = 0;

    // Comparamos cada palabra al llegar al espacio
    for ($i = 0; $i <= strlen($frase); $i++) {
        if ($i < strlen($frase) && $frase[$i] != " ") {
            $palabra .= $frase[$i];
        } else {
            if (strlen($palabra) > $longitudMayor) {
                $longitudMayor = strlen($palabra);
                $resultado = $palabra;
            }
            $palabra = "";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 10 - Palabra más larga</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Palabra más larga</h1>
    <form method="post">
        <label for="frase" class="form-label">Frase</label>
        <input type="text" name="frase" id="frase" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Buscar</button>
    </form>
    <?php if (isset($_POST["frase"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
