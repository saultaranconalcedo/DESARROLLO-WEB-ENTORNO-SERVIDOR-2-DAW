<?php
$mayor = 0;
$menor = 9;
if (isset($_POST["numero"])) {
    $numero = (int) $_POST["numero"];

    // Revisamos cada cifra del número
    do {
        $cifra = $numero % 10;
        if ($cifra > $mayor) {
            $mayor = $cifra;
        }
        if ($cifra < $menor) {
            $menor = $cifra;
        }
        $numero = (int) ($numero / 10);
    } while ($numero > 0);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 15 - Cifra mayor y menor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Cifra mayor y menor</h1>
    <form method="post">
        <label for="numero" class="form-label">Número entero positivo</label>
        <input type="number" name="numero" id="numero" class="form-control" min="0" required>
        <button type="submit" class="btn btn-primary mt-3">Analizar</button>
    </form>
    <?php if (isset($_POST["numero"])) { ?>
        <p class="alert alert-info mt-3">Mayor: <?php echo $mayor; ?> / Menor: <?php echo $menor; ?></p>
    <?php } ?>
</div>
</body>
</html>
