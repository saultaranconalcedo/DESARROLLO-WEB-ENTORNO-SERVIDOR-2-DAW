<?php
$resultado = 0;
if (isset($_POST["frase"])) {
    $frase = $_POST["frase"];
    $dentroPalabra = false;

    // Contamos cada espacio que inicia una palabra
    for ($i = 0; $i < strlen($frase); $i++) {
        if ($frase[$i] != " " && $dentroPalabra == false) {
            $resultado++;
            $dentroPalabra = true;
        } elseif ($frase[$i] == " ") {
            $dentroPalabra = false;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 9 - Contar palabras</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Contar palabras sin explode()</h1>
    <form method="post">
        <label for="frase" class="form-label">Frase</label>
        <input type="text" name="frase" id="frase" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Contar</button>
    </form>
    <?php if (isset($_POST["frase"])) { ?>
        <p class="alert alert-info mt-3"><?php echo $resultado; ?> palabras</p>
    <?php } ?>
</div>
</body>
</html>
