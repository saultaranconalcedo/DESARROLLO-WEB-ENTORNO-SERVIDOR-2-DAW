<?php
$resultado = 0;
if (isset($_POST["frase"]) && isset($_POST["palabra"])) {
    $frase = strtolower($_POST["frase"]);
    $palabra = strtolower($_POST["palabra"]);
    $longitudPalabra = strlen($palabra);

    // Comparamos la palabra desde cada posición de la frase
    if ($longitudPalabra > 0) {
        for ($i = 0; $i <= strlen($frase) - $longitudPalabra; $i++) {
            $coincide = true;
            for ($j = 0; $j < $longitudPalabra; $j++) {
                if ($frase[$i + $j] != $palabra[$j]) {
                    $coincide = false;
                }
            }
            if ($coincide) {
                $resultado++;
                $i += $longitudPalabra - 1;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 19 - Contar apariciones de una palabra</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>¿Cuántas veces aparece una palabra?</h1>
    <form method="post">
        <label for="frase" class="form-label">Frase</label>
        <input type="text" name="frase" id="frase" class="form-control" required>
        <label for="palabra" class="form-label mt-3">Palabra que quieres buscar</label>
        <input type="text" name="palabra" id="palabra" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Contar</button>
    </form>
    <?php if (isset($_POST["frase"]) && isset($_POST["palabra"])) { ?>
        <p class="alert alert-info mt-3">Aparece <?php echo $resultado; ?> veces</p>
    <?php } ?>
</div>
</body>
</html>
