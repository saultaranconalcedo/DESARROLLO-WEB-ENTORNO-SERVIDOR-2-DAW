<?php
$resultado = "";
if (isset($_POST["palabra"]) && isset($_POST["posiciones"])) {
    $palabra = $_POST["palabra"];
    $longitud = strlen($palabra);

    if ($longitud > 0) {
        $posiciones = (int) $_POST["posiciones"] % $longitud;

        // Ponemos primero las letras del final
        for ($i = $longitud - $posiciones; $i < $longitud; $i++) {
            $resultado .= $palabra[$i];
        }
        for ($i = 0; $i < $longitud - $posiciones; $i++) {
            $resultado .= $palabra[$i];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 17 - Rotar una palabra</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Rotar una palabra</h1>
    <form method="post">
        <label for="palabra" class="form-label">Palabra</label>
        <input type="text" name="palabra" id="palabra" class="form-control" required>
        <label for="posiciones" class="form-label mt-3">Posiciones a la derecha</label>
        <input type="number" name="posiciones" id="posiciones" class="form-control" min="0" required>
        <button type="submit" class="btn btn-primary mt-3">Rotar</button>
    </form>
    <?php if (isset($_POST["palabra"]) && isset($_POST["posiciones"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
