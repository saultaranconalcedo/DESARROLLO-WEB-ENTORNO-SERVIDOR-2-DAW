<?php
$resultado = "";
if (isset($_POST["palabra"]) && isset($_POST["letra"])) {
    $palabra = $_POST["palabra"];
    $letra = $_POST["letra"];

    // Añadimos solo los caracteres diferentes de la letra elegida
    for ($i = 0; $i < strlen($palabra); $i++) {
        if ($palabra[$i] != $letra) {
            $resultado .= $palabra[$i];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 18 - Eliminar una letra</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Eliminar una letra repetida</h1>
    <form method="post">
        <label for="palabra" class="form-label">Palabra</label>
        <input type="text" name="palabra" id="palabra" class="form-control" required>
        <label for="letra" class="form-label mt-3">Letra que quieres eliminar</label>
        <input type="text" name="letra" id="letra" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Eliminar</button>
    </form>
    <?php if (isset($_POST["palabra"]) && isset($_POST["letra"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
