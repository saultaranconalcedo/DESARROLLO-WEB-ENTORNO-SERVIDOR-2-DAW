<?php
$resultado = "";
if (isset($_POST["palabra1"]) && isset($_POST["palabra2"])) {
    $palabra1 = strtolower($_POST["palabra1"]);
    $palabra2 = strtolower($_POST["palabra2"]);
    $sonAnagramas = true;

    if (strlen($palabra1) != strlen($palabra2)) {
        $sonAnagramas = false;
    } else {
        // Contamos cada letra en las dos palabras
        for ($i = 0; $i < strlen($palabra1); $i++) {
            $veces1 = 0;
            $veces2 = 0;
            for ($j = 0; $j < strlen($palabra1); $j++) {
                if ($palabra1[$i] == $palabra1[$j]) {
                    $veces1++;
                }
                if ($palabra1[$i] == $palabra2[$j]) {
                    $veces2++;
                }
            }
            if ($veces1 != $veces2) {
                $sonAnagramas = false;
            }
        }
    }

    if ($sonAnagramas) {
        $resultado = "Son anagramas.";
    } else {
        $resultado = "No son anagramas.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 8 - Comprobar anagramas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Comprobar anagramas</h1>
    <form method="post">
        <label for="palabra1" class="form-label">Primera palabra</label>
        <input type="text" name="palabra1" id="palabra1" class="form-control" required>
        <label for="palabra2" class="form-label mt-3">Segunda palabra</label>
        <input type="text" name="palabra2" id="palabra2" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Comprobar</button>
    </form>
    <?php if (isset($_POST["palabra1"]) && isset($_POST["palabra2"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
