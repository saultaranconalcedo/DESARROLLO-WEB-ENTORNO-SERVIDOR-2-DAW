<?php
$resultado = "";
if (isset($_POST["frase"])) {
    $frase = $_POST["frase"];
    $palabra = "";

    // Guardamos cada palabra delante de las anteriores
    for ($i = 0; $i < strlen($frase); $i++) {
        if ($frase[$i] == " ") {
            if ($palabra != "") {
                if ($resultado != "") {
                    $resultado = $palabra . " " . $resultado;
                } else {
                    $resultado = $palabra;
                }
                $palabra = "";
            }
        } else {
            $palabra .= $frase[$i];
        }
    }

    if ($palabra != "") {
        if ($resultado != "") {
            $resultado = $palabra . " " . $resultado;
        } else {
            $resultado = $palabra;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 4 - Dar la vuelta a una frase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Dar la vuelta a una frase</h1>
    <form method="post">
        <label for="frase" class="form-label">Frase</label>
        <input type="text" name="frase" id="frase" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Invertir orden</button>
    </form>
    <?php if (isset($_POST["frase"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
