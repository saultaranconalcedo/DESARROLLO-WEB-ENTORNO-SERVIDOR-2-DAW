<?php
$resultado = "";
if (isset($_POST["palabra"])) {
    $palabra = $_POST["palabra"];
    $longitud = strlen($palabra);

    if ($longitud > 0) {
        $caracterActual = $palabra[0];
        $contador = 1;

        // Contamos las letras iguales que aparecen seguidas
        for ($i = 1; $i < $longitud; $i++) {
            if ($palabra[$i] == $caracterActual) {
                $contador++;
            } else {
                $resultado .= $caracterActual . $contador;
                $caracterActual = $palabra[$i];
                $contador = 1;
            }
        }
        $resultado .= $caracterActual . $contador;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 20 - Compresor de cadenas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Compresor de cadenas</h1>
    <form method="post">
        <label for="palabra" class="form-label">Palabra</label>
        <input type="text" name="palabra" id="palabra" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Comprimir</button>
    </form>
    <?php if (isset($_POST["palabra"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
