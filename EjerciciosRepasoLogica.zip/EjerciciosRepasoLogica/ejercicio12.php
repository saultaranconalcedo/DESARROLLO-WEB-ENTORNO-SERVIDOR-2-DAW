<?php
$resultado = 0;
if (isset($_POST["numero"])) {
    $numero = (int) $_POST["numero"];
    $original = $numero;
    $numero = abs($numero);

    // Sacamos la última cifra con el resto de 10
    while ($numero > 0) {
        $cifra = $numero % 10;
        $resultado = $resultado * 10 + $cifra;
        $numero = (int) ($numero / 10);
    }

    if ($original < 0) {
        $resultado = -$resultado;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 12 - Cifras al revés</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Cifras de un número al revés</h1>
    <form method="post">
        <label for="numero" class="form-label">Número entero</label>
        <input type="number" name="numero" id="numero" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Invertir cifras</button>
    </form>
    <?php if (isset($_POST["numero"])) { ?>
        <p class="alert alert-info mt-3"><?php echo $resultado; ?></p>
    <?php } ?>
</div>
</body>
</html>
