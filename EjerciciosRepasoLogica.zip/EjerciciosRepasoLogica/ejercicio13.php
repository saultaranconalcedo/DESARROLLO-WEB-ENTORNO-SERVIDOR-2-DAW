<?php
$resultado = "";
if (isset($_POST["numero"])) {
    $numero = abs((int) $_POST["numero"]);
    $original = $numero;
    $invertido = 0;

    // Construimos el número invertido cifra a cifra
    while ($numero > 0) {
        $cifra = $numero % 10;
        $invertido = $invertido * 10 + $cifra;
        $numero = (int) ($numero / 10);
    }

    if ($original == $invertido) {
        $resultado = "PALÍNDROMO";
    } else {
        $resultado = "NO ES PALÍNDROMO";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 13 - Número palíndromo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Número palíndromo</h1>
    <form method="post">
        <label for="numero" class="form-label">Número entero</label>
        <input type="number" name="numero" id="numero" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Comprobar</button>
    </form>
    <?php if (isset($_POST["numero"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
