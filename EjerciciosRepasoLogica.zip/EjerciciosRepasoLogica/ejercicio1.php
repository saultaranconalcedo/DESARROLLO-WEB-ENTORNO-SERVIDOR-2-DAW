<?php
$resultado = "";
if (isset($_POST["palabra"])) {
    $palabra = $_POST["palabra"];
    $resultado = "";

    // Recorremos la palabra desde el final hasta el principio
    for ($i = strlen($palabra) - 1; $i >= 0; $i--) {
        $resultado .= $palabra[$i];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 1 - Dar la vuelta a una palabra</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Dar la vuelta a una palabra</h1>
    <form method="post">
        <label for="palabra" class="form-label">Palabra</label>
        <input type="text" name="palabra" id="palabra" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Invertir</button>
    </form>
    <?php if (isset($_POST["palabra"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
