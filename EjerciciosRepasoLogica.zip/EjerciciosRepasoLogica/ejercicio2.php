<?php
$resultado = "";
if (isset($_POST["palabra"])) {
    $palabra = $_POST["palabra"];
    $invertida = "";

    // Creamos la palabra al revés
    for ($i = strlen($palabra) - 1; $i >= 0; $i--) {
        $invertida .= $palabra[$i];
    }

    if (strtolower($palabra) == strtolower($invertida)) {
        $resultado = "PALÍNDROMO";
    } else {
        $resultado = "NO ES PALÍNDROMO";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 2 - Palíndromo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Comprobar si es palíndromo</h1>
    <form method="post">
        <label for="palabra" class="form-label">Palabra</label>
        <input type="text" name="palabra" id="palabra" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Comprobar</button>
    </form>
    <?php if (isset($_POST["palabra"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
