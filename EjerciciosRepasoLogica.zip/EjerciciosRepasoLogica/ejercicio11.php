<?php
$palabraMayor = "";
$segundaPalabra = "";
if (isset($_POST["frase"])) {
    $frase = $_POST["frase"];
    $palabra = "";

    // Guardamos las dos palabras de mayor longitud
    for ($i = 0; $i <= strlen($frase); $i++) {
        if ($i < strlen($frase) && $frase[$i] != " ") {
            $palabra .= $frase[$i];
        } else {
            if (strlen($palabra) > strlen($palabraMayor)) {
                $segundaPalabra = $palabraMayor;
                $palabraMayor = $palabra;
            } elseif (strlen($palabra) > strlen($segundaPalabra)) {
                $segundaPalabra = $palabra;
            }
            $palabra = "";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 11 - Segunda palabra más larga</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Segunda palabra más larga</h1>
    <form method="post">
        <label for="frase" class="form-label">Frase</label>
        <input type="text" name="frase" id="frase" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Buscar</button>
    </form>
    <?php if (isset($_POST["frase"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($segundaPalabra); ?></p>
    <?php } ?>
</div>
</body>
</html>
