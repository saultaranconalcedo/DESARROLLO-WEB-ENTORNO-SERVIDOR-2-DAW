<?php
$resultado = 0;
if (isset($_POST["numero"])) {
    $numero = (int) $_POST["numero"];

    // Sumamos las cifras desde la última
    while ($numero > 0) {
        $cifra = $numero % 10;
        $resultado += $cifra;
        $numero = (int) ($numero / 10);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 14 - Suma de cifras</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Suma de cifras</h1>
    <form method="post">
        <label for="numero" class="form-label">Número entero positivo</label>
        <input type="number" name="numero" id="numero" class="form-control" min="0" required>
        <button type="submit" class="btn btn-primary mt-3">Sumar</button>
    </form>
    <?php if (isset($_POST["numero"])) { ?>
        <p class="alert alert-info mt-3"><?php echo $resultado; ?></p>
    <?php } ?>
</div>
</body>
</html>
