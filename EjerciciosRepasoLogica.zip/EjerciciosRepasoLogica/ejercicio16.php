<?php
$resultado = "";
if (isset($_POST["numero1"])) {
    $mayorCantidad = -1;
    $numerosConMasPares = "";

    // Contamos las cifras pares de cada número
    for ($i = 1; $i <= 5; $i++) {
        $numero = abs((int) $_POST["numero" . $i]);
        $numeroOriginal = (int) $_POST["numero" . $i];
        $cantidadPares = 0;

        do {
            $cifra = $numero % 10;
            if ($cifra % 2 == 0) {
                $cantidadPares++;
            }
            $numero = (int) ($numero / 10);
        } while ($numero > 0);

        if ($cantidadPares > $mayorCantidad) {
            $mayorCantidad = $cantidadPares;
            $numerosConMasPares = $numeroOriginal;
        } elseif ($cantidadPares == $mayorCantidad) {
            $numerosConMasPares .= ", " . $numeroOriginal;
        }
    }

    $resultado = $numerosConMasPares . " tienen " . $mayorCantidad . " cifras pares";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 16 - Número con más cifras pares</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Número con más cifras pares</h1>
    <form method="post">
        <?php for ($i = 1; $i <= 5; $i++) { ?>
            <label for="numero<?php echo $i; ?>" class="form-label">Número <?php echo $i; ?></label>
            <input type="number" name="numero<?php echo $i; ?>" id="numero<?php echo $i; ?>" class="form-control mb-2" required>
        <?php } ?>
        <button type="submit" class="btn btn-primary mt-2">Comparar</button>
    </form>
    <?php if (isset($_POST["numero1"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
