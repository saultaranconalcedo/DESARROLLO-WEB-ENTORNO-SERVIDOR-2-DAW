<?php
$resultado = "";
if (isset($_POST["frase"])) {
    $frase = $_POST["frase"];
    $palabra = "";

    // Invertimos cada palabra al llegar a un espacio
    for ($i = 0; $i < strlen($frase); $i++) {
        if ($frase[$i] == " ") {
            for ($j = strlen($palabra) - 1; $j >= 0; $j--) {
                $resultado .= $palabra[$j];
            }
            $resultado .= " ";
            $palabra = "";
        } else {
            $palabra .= $frase[$i];
        }
    }

    for ($j = strlen($palabra) - 1; $j >= 0; $j--) {
        $resultado .= $palabra[$j];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 3 - Invertir cada palabra</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Dar la vuelta a cada palabra</h1>
    <form method="post">
        <label for="frase" class="form-label">Frase</label>
        <input type="text" name="frase" id="frase" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Invertir palabras</button>
    </form>
    <?php if (isset($_POST["frase"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
