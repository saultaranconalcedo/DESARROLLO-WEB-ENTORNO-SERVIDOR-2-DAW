<?php
$vocales = array("a" => 0, "e" => 0, "i" => 0, "o" => 0, "u" => 0);
if (isset($_POST["palabra"])) {
    $palabra = strtolower($_POST["palabra"]);

    // Contamos las vocales una a una
    for ($i = 0; $i < strlen($palabra); $i++) {
        if ($palabra[$i] == "a") {
            $vocales["a"]++;
        } elseif ($palabra[$i] == "e") {
            $vocales["e"]++;
        } elseif ($palabra[$i] == "i") {
            $vocales["i"]++;
        } elseif ($palabra[$i] == "o") {
            $vocales["o"]++;
        } elseif ($palabra[$i] == "u") {
            $vocales["u"]++;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 5 - Contar vocales</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Contar vocales</h1>
    <form method="post">
        <label for="palabra" class="form-label">Palabra</label>
        <input type="text" name="palabra" id="palabra" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Contar</button>
    </form>
    <?php if (isset($_POST["palabra"])) { ?>
        <div class="alert alert-info mt-3">
            <p>a: <?php echo $vocales["a"]; ?></p>
            <p>e: <?php echo $vocales["e"]; ?></p>
            <p>i: <?php echo $vocales["i"]; ?></p>
            <p>o: <?php echo $vocales["o"]; ?></p>
            <p>u: <?php echo $vocales["u"]; ?></p>
        </div>
    <?php } ?>
</div>
</body>
</html>
