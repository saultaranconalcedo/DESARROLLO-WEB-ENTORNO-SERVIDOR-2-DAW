<?php
$resultado = "";
if (isset($_POST["palabra"])) {
    $palabra = strtolower($_POST["palabra"]);
    $mayor = 0;
    $letraMayor = "";

    // Comparamos cuántas veces aparece cada carácter
    for ($i = 0; $i < strlen($palabra); $i++) {
        $veces = 0;
        for ($j = 0; $j < strlen($palabra); $j++) {
            if ($palabra[$i] == $palabra[$j]) {
                $veces++;
            }
        }
        if ($veces > $mayor) {
            $mayor = $veces;
            $letraMayor = $palabra[$i];
        }
    }

    $resultado = "La letra más repetida es: " . $letraMayor . " (" . $mayor . " veces)";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 6 - Letra más repetida</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>La letra más repetida</h1>
    <form method="post">
        <label for="palabra" class="form-label">Palabra</label>
        <input type="text" name="palabra" id="palabra" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Buscar</button>
    </form>
    <?php if (isset($_POST["palabra"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
