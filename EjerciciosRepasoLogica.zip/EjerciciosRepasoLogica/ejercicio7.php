<?php
$resultado = "";
if (isset($_POST["palabra"])) {
    $palabra = $_POST["palabra"];

    // Añadimos el carácter solo si todavía no está
    for ($i = 0; $i < strlen($palabra); $i++) {
        $existe = false;
        for ($j = 0; $j < strlen($resultado); $j++) {
            if ($palabra[$i] == $resultado[$j]) {
                $existe = true;
            }
        }
        if ($existe == false) {
            $resultado .= $palabra[$i];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ejercicio 7 - Eliminar caracteres repetidos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Eliminar caracteres repetidos</h1>
    <form method="post">
        <label for="palabra" class="form-label">Palabra</label>
        <input type="text" name="palabra" id="palabra" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3">Eliminar repetidos</button>
    </form>
    <?php if (isset($_POST["palabra"])) { ?>
        <p class="alert alert-info mt-3"><?php echo htmlspecialchars($resultado); ?></p>
    <?php } ?>
</div>
</body>
</html>
